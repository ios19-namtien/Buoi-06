//
//  main.m
//  learning_array
//
//  Created by NguyenTien on 12/10/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "hdt_AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([hdt_AppDelegate class]));
    }
}
