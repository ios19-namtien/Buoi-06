//
//  hdt_ViewController.m
//  learning_array
//
//  Created by NguyenTien on 12/10/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import "hdt_ViewController.h"

@interface hdt_ViewController ()
@end

@implementation hdt_ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)createArray:(id)sender {
    // Tao mang gom 100 phan tu
    int numberOfArray = 100;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < numberOfArray; i++)
    {
        [array addObject:[NSString stringWithFormat:@"%i", i]];
    }
    // In mang ra ngoai
    NSLog(@"\n++++++++++++++++++++++++");
    for (int i = 0; i < numberOfArray; i++)
    {
        printf("\t %i", [[array objectAtIndex:i] integerValue]);
    }
}
- (IBAction)sortArray:(id)sender {
    int numberOfArray = 100;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < numberOfArray; i++)
    {
        [array addObject:[NSString stringWithFormat:@"%i", i]];
    }
    
    NSLog(@"\n++++++++++++++++++++++++");
    // Sap xep mang theo thu tu giam dan
    for (int i = 0; i < numberOfArray; i++) {
        for (int j = i+1; j < numberOfArray; j++)
        {
            if ([[array objectAtIndex:i] integerValue] < [[array objectAtIndex:j] integerValue])
            {
                [array exchangeObjectAtIndex:j withObjectAtIndex:i];
            }
        }
    }
    // In mang sau khi sap xep ra ngoai
    NSLog(@"\n++++++++++++++++++++++++");
    NSLog(@"\nMang sau khi sap xep la:");
    for (int i = 0; i < numberOfArray; i++)
    {
        printf("\t %i", [[array objectAtIndex:i] integerValue]);
    }
}

- (IBAction)createArrayRandom:(id)sender {
    int numberOfArray = 100;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    // Tao mang random cac phan tu
    for (int i = 0; i < numberOfArray; i++)
    {
        [array addObject:[NSString stringWithFormat:@"%i", arc4random()%100]];
    }
    
    // In mang ra ngoai
    NSLog(@"\n++++++++++++++++++++++++");
    NSLog(@"\nMang cac phan tu random:");
    NSLog(@"\n++++++++++++++++++++++++");
    
    for (int i = 0; i < numberOfArray; i++)
    {
        printf("\t %i", [[array objectAtIndex:i] integerValue]);
    }
}

- (IBAction)clearSampleNumberArray:(id)sender {
    int numberOfArray = 100;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < numberOfArray; i++)
    {
        [array addObject:[NSString stringWithFormat:@"%i", arc4random()%100]];
    }
    
    // In mang ra ngoai
    NSLog(@"\n++++++++++++++++++++++++");
    NSLog(@"\nMang cac phan tu random:");
    NSLog(@"\n++++++++++++++++++++++++");
    
    for (int i = 0; i < numberOfArray; i++)
    {
        printf("\t %i", [[array objectAtIndex:i] integerValue]);
    }
    
    for (int i = 0; i < numberOfArray; i++) {
        for (int j = i+1; j < numberOfArray; j++)
        {
            if ([[array objectAtIndex:i] integerValue] == [[array objectAtIndex:j] integerValue])
            {
                [array removeObjectAtIndex:j];
            }
        }
    }
    
    // In mang ra ngoai
    NSLog(@"\n++++++++++++++++++++++++");
    NSLog(@"\nMang cac phan tu sau khi da xoa la:");
    NSLog(@"\n++++++++++++++++++++++++");
    
    for (int i = 0; i < numberOfArray; i++)
    {
        printf("\t %i", [[array objectAtIndex:i] integerValue]);
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
